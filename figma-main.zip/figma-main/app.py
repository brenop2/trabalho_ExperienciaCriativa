# backend.py
import json
import threading
import time
from datetime import datetime
from flask import Flask, request, jsonify
import mysql.connector
import paho.mqtt.client as mqtt

#configurações
MQTT_BROKER = "broker.mqttdashboard.com"  
MQTT_PORT = 1883
MQTT_TOPIC_SUB = "ponto/esp32/registro"
MQTT_TOPIC_ACK_PREFIX = "ponto/esp32/ack/"

MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "PUC@1234",
    "database": "expcri",
    "autocommit": True
}

DEVICE_ID = "esp32_prototipo_01" 

app = Flask(__name__)

def insert_ponto(device_id, method, value):
    cnx = mysql.connector.connect(**MYSQL_CONFIG)
    cursor = cnx.cursor()
    sql = "INSERT INTO pontos (device_id, method, value) VALUES (%s, %s, %s)"
    cursor.execute(sql, (device_id, method, value))
    cnx.commit()
    cursor.close()
    cnx.close()


def on_connect(client, userdata, flags, rc):
    print("MQTT conectado com código", rc)
    client.subscribe(MQTT_TOPIC_SUB)
    print("Inscrito em", MQTT_TOPIC_SUB)

def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode()
        print("Mensagem recebida:", payload)
        data = json.loads(payload)
        device_id = data.get("device_id", "unknown")
        method = data.get("method")
        value = data.get("value")
        timestamp = data.get("timestamp", None)
        if method not in ("rfid", "cpf", "manual"):
            print("Método inválido:", method)
            return
        insert_ponto(device_id, method, value)
        ack_topic = MQTT_TOPIC_ACK_PREFIX + device_id
        ack = {"status": "ok", "method": method, "value": value, "server_ts": datetime.utcnow().isoformat()}
        client.publish(ack_topic, json.dumps(ack))
        print("ACK publicado em", ack_topic)
    except Exception as e:
        print("Erro on_message:", e)

def start_mqtt_client():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    client.loop_forever()

@app.route("/")
def index():
    return "Backend de Ponto - OK"

@app.route("/manual_register", methods=["POST"])
def manual_register():
    """
    Espera JSON: { "device_id": "web", "method": "manual", "value": "cpf_ou_nome" }
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON esperado"}), 400
    device_id = data.get("device_id", "web_manual")
    method = data.get("method", "manual")
    value = data.get("value")
    if not value:
        return jsonify({"error": "value obrigatório"}), 400
    try:
        insert_ponto(device_id, method, value)
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    mqtt_thread = threading.Thread(target=start_mqtt_client, daemon=True)
    mqtt_thread.start()
    app.run(host="0.0.0.0", port=5000, debug=True)

