# **PROJETO: SISTEMA INTEGRADO DE GERENCIAMENTO DE VOLUNTÁRIOS - HOSPITAL CAJURU**

## 1. INTRODUÇÃO AO PROJETO

**Objetivo do Projeto:**
Desenvolver uma solução tecnológica integrada, composta por um dispositivo físico e uma plataforma web, para automatizar e centralizar o gerenciamento de voluntários do Hospital Cajuru. O sistema tem como finalidade principal modernizar o processo de cadastro, a guarda do termo de responsabilidade e o registro de frequência (pontos de entrada e saída), assegurando o cumprimento das normas institucionais e a total rastreabilidade das atividades.

**Contexto e Cenário (Mini Mundo):**
O Hospital Cajuru possui uma significativa e valiosa força de trabalho voluntária, essencial para o suporte em diversas áreas. No entanto, para manter a idoneidade e conformidade com as diretrizes internas, é importante que esses voluntários não possuam vínculo empregatício ou associativo com o Grupo Marista, necessitando, para tanto, da assinatura e guarda de um termo de ciência e responsabilidade.

Atualmente, o controle de presença e documentação é realizado majoritariamente de forma manual e descentralizada. Essa prática está sujeita a uma série de desafios:

*   **Inconsistências e Erros:** Registros em planilhas ou papel são propensos a falhas humanas de preenchimento e cálculo.
*   **Dificuldade de Rastreamento:** Localizar o histórico de pontos de um voluntário ou verificar a assinatura de um termo específico é um processo lento e burocrático.
*   **Ineficiência Operacional:** A geração de relatórios confiáveis sobre horas trabalhadas é complexa, consumindo tempo da equipe administrativa.
*   **Fragilidade na Guarda Documental:** Os termos de voluntariado em papel estão sujeitos a extravios ou danos.

Este projeto surge para solucionar essas limitações de forma elegante e eficaz, introduzindo um processo digital, seguro e unificado. A solução beneficia tanto a administração do hospital, que ganha em agilidade e confiabilidade dos dados, quanto os próprios voluntários, que experimentam um processo de registro de ponto ágil e moderno.

**Atores Principais do Cenário:**

*   **Voluntários:** Registram seu ponto de entrada e saída e possuem seu termo de adesão digitalmente arquivado.
*   **Administradores do Sistema:** Responsáveis pelo gerenciamento de cadastros, pela emissão de relatórios e pela supervisão de todo o processo de voluntariado.
*   **Sistema Embarcado (ESP32):** Atua como a interface física e acessível para o registro de ponto, instalado em locais estratégicos.
*   **Plataforma Web:** Funciona como o centro de controle centralizado para todas as operações de gestão.

**Exemplo de Fluxo de Uso:**
Ao chegar ao hospital, a voluntária Fulana de Ciclana se dirige ao dispositivo embarcado. Ela aproxima seu crachá pessoal do leitor, registrando sua entrada de forma instantânea e sem contato. Ao final de seu turno, como não está com o crachá, ela digita seu CPF no teclado do mesmo dispositivo para registrar a saída. Ambos os eventos são transmitidos e consolidados imediatamente em sua ficha na plataforma web, disponível para a administração.

---

## 2. REQUISITOS DO SISTEMA

### **Requisitos Funcionais (O que o sistema deve fazer):**

*   **RF1 - Cadastro de Voluntários:** O sistema deve permitir o registro completo de voluntários, incluindo identificação única, nome completo, CPF, e-mail, telefone, data de nascimento, endereço, área de atuação preferencial e status (Ativo ou Inativo).
*   **RF2 - Gestão de Termos de Adesão:** O sistema deve armazenar uma versão digitalizada do termo de voluntariado devidamente assinado, vinculando-o de forma permanente e auditável ao cadastro do voluntário.
*   **RF3 - Registro de Ponto via RFID:** O dispositivo físico deve permitir o registro de entrada e saída por meio da leitura de um cartão de identificação com tecnologia RFID.
*   **RF4 - Registro de Ponto via CPF:** O mesmo dispositivo deve oferecer uma alternativa segura para registro de ponto mediante a digitação do CPF do voluntário em um teclado matricial.
*   **RF5 - Registro Manual de Ponto:** A plataforma web deve disponibilizar uma funcionalidade para que um administrador registre manualmente um ponto de entrada ou saída, cobrindo situações excepcionais, como o esquecimento do cartão.
*   **RF6 - Comunicação em Tempo Real:** O dispositivo embarcado deve transmitir instantaneamente todos os eventos de registro de ponto (identificação do voluntário, data, hora e tipo de registro) para um servidor central, utilizando o protocolo de comunicação MQTT para garantir baixa latência e confiabilidade.
*   **RF7 - Consolidação de Dados:** A plataforma web deve receber, processar e armazenar de forma segura todos os registros de ponto enviados pelo dispositivo em um banco de dados, criando um histórico completo.
*   **RF8 - Gerenciamento de Usuários do Sistema:** A plataforma web deve permitir a um usuário administrador realizar todas as operações básicas (criar, visualizar, atualizar e desativar) nas contas de acesso ao sistema.
*   **RF9 - Gerenciamento de Cadastros:** A plataforma web deve permitir a um usuário administrador realizar todas as operações básicas (criar, visualizar, atualizar e desativar) no cadastro de voluntários.
*   **RF10 - Controle de Acesso e Múltiplos Perfis:** O sistema web deve distinguir claramente dois perfis de usuário: **Administrador**, com acesso total a todas as funcionalidades de gestão, e **Voluntário**, com permissão para visualizar seu próprio histórico de pontos e registrar ponto via web quando necessário.

### **Requisitos Não-Funcionais (Qualidades e Restrições do Sistema):**

*   **RNF1 - Segurança e Privacidade:** O sistema deve adotar práticas robustas de segurança da informação. Senhas de usuário devem ser armazenadas de forma irreversível (hashed) usando algoritmos modernos (ex.: bcrypt). Dados pessoais sensíveis, como CPF, devem ser tratados com cuidado, minimizando sua exposição e seguindo as melhores práticas de proteção.
*   **RNF2 - Usabilidade e Acessibilidade:** Tanto a interface web quanto o dispositivo físico devem ser intuitivos, de fácil aprendizado e operação, projetados para um público com diferentes níveis de familiaridade com tecnologia, garantindo uma experiência eficiente e sem obstáculos.
*   **RNF3 - Identidade Visual Institucional:** A interface da plataforma web deve ser desenvolvida para refletir a identidade visual da PUCPR e do Hospital Cajuru, incorporando sua paleta de cores oficial, logotipo e diretrizes de tipografia. Isso promove o reconhecimento institucional, transmisse confiança e oferece uma experiência visualmente coesa e integrada ao ecossistema da instituição.

---

## 3. ARQUITETURA DO SISTEMA

**Descrição do Banco de Dados (Modelo Conceitual - Entidades e Relacionamentos):**

A estrutura de dados foi planejada para organizar as informações de forma lógica, segura e relacional. As tabelas principais são:

1.  **usuarios:** Armazena as credenciais e permissões de quem acessa a plataforma web (`id`, `nome`, `email`, `senha_hash`, `tipo_usuario` [Admin/Voluntario]).
2.  **voluntarios:** Contém todas as informações pessoais e profissionais de cada voluntário (`id`, `cpf`, `nome`, `email`, `telefone`, `data_nascimento`, `endereco`, `area_atuacao`, `status` [Ativo/Inativo], `termo_assinado` [BOOL], `data_cadastro`).
3.  **registros_ponto:** Registra cada evento de entrada e saída, criando um histórico de frequência detalhado e auditável (`id`, `voluntario_id` (Chave Estrangeira para voluntarios.id), `data_hora_registro`, `tipo_registro` [Entrada/Saída], `metodo_registro` [RFID/Teclado/Web]).

---

## 4. IDEIA DO SISTEMA EMBARCADO

**Componentes de Hardware:**
*   Microcontrolador ESP32.
*   Módulo Leitor de Cartões RFID RC522.
*   Teclado Matricial 3x4.
*   LEDs para confirmação visual.

**Funcionamento e Interação:**
O dispositivo será instalado em locais de fácil acesso para os voluntários, servindo como o ponto de contato físico principal para o registro de frequência. Sua operação se divide em dois fluxos principais:

1.  **Registro por Cartão (Modo RFID):** O voluntário aproxima seu crachá pessoal do leitor. O sistema identifica o código único do cartão, que está previamente associado ao seu cadastro no banco de dados. O registro é então processado e o LED verde acende, sinalizando sucesso de forma não verbal e eficiente.

2.  **Registro por CPF (Modo Teclado):** Caso o voluntário não esteja com o cartão, ele pode inserir seu CPF diretamente no teclado matricial. O sistema valida o número e, se correto e vinculado a um cadastro ativo, procede com o registro da mesma forma, acendendo o LED verde.

**Coleta e Transmissão de Dados:**
A ESP32 é o componente central responsável por orquestrar todo o processo. Ela captura a ação do voluntário (seja via RFID ou teclado), compõe uma mensagem contendo sua identificação, o carimbo de data/hora exato e o tipo de registro (entrada ou saída). Esta mensagem é então enviada de maneira confiável e em tempo real, via protocolo MQTT, para a plataforma web central, onde será armazenada definitivamente. Os LEDs fornecem um retorno visual claro e imediato sobre o status de cada operação.

