import network
import time
import ujson as json
from machine import Pin, SPI
from umqtt.simple import MQTTClient
from mfrc522 import MFRC522


WIFI_SSID = "Visitantes"
WIFI_PASS = ""

MQTT_BROKER = "broker.mqttdashboard.com"
MQTT_PORT = 1883
DEVICE_ID = "esp32_prototipo_01"
TOPIC_PUBLISH = "ponto/esp32/registro"
TOPIC_ACK = "ponto/esp32/ack/" + DEVICE_ID

SCK_PIN = 18
MOSI_PIN = 23
MISO_PIN = 19
CS_PIN = 5
RST_PIN = 17

ROW_PINS = [32, 33, 25, 26]
COL_PINS = [27, 14, 12, 13]

#ledzinhos
LED_GREEN_PIN = 2
LED_RED_PIN = 4

KEYMAP = [
    ['1','2','3','A'],
    ['4','5','6','B'],
    ['7','8','9','C'],
    ['*','0','#','D']
]


led_green = Pin(LED_GREEN_PIN, Pin.OUT)
led_red = Pin(LED_RED_PIN, Pin.OUT)

def blink_led(pin, times=2, delay=0.15):
    for _ in range(times):
        pin.on()
        time.sleep(delay)
        pin.off()
        time.sleep(delay)

#wifi
def connect_wifi():
    sta = network.WLAN(network.STA_IF)
    if not sta.isconnected():
        print("Conectando WiFi...")
        sta.active(True)
        sta.connect(WIFI_SSID, WIFI_PASS)
        for i in range(30):
            if sta.isconnected():
                break
            time.sleep(1)
    print("WiFi conectado:", sta.ifconfig())

class Keypad:
    def __init__(self, row_pins, col_pins, keymap):
        self.rows = [Pin(p, Pin.OUT) for p in row_pins]
        self.cols = [Pin(p, Pin.IN, Pin.PULL_DOWN) for p in col_pins]
        self.map = keymap
        for r in self.rows:
            r.off()

    def getkey(self):
        for i, r in enumerate(self.rows):
            r.on()
            for j, c in enumerate(self.cols):
                if c.value() == 1:
                    time.sleep_ms(20)
                    if c.value() == 1:
                        while c.value() == 1:
                            pass
                        r.off()
                        return self.map[i][j]
            r.off()
        return None

mqtt_client = None

def mqtt_connect():
    global mqtt_client
    mqtt_client = MQTTClient(DEVICE_ID, MQTT_BROKER, port=MQTT_PORT)
    mqtt_client.set_callback(mqtt_callback)
    mqtt_client.connect()
    mqtt_client.subscribe(TOPIC_ACK)
    print("MQTT conectado e inscrito em", TOPIC_ACK)

def mqtt_callback(topic, msg):
    try:
        topic = topic.decode()
        msg = msg.decode()
        print("ACK recebido:", topic, msg)
        blink_led(led_green, times=3)
    except Exception as e:
        print("Erro ack:", e)

def mqtt_publish(payload):
    try:
        mqtt_client.publish(TOPIC_PUBLISH, json.dumps(payload))
        print("Publicado no MQTT:", payload)
        return True
    except Exception as e:
        print("Erro publish:", e)
        return False

spi = SPI(1, baudrate=1000000, polarity=0, phase=0,
          sck=Pin(SCK_PIN), mosi=Pin(MOSI_PIN), miso=Pin(MISO_PIN))
rc522 = MFRC522(spi, Pin(CS_PIN), Pin(RST_PIN))
keypad = Keypad(ROW_PINS, COL_PINS, KEYMAP)

def read_rfid_once(timeout=15):
    print("Aguardando cartão (timeout {}s)...".format(timeout))
    start = time.time()
    while time.time() - start < timeout:
        (stat, tag_type) = rc522.request(rc522.REQIDL)
        if stat == rc522.OK:
            (stat, raw_uid) = rc522.anticoll()
            if stat == rc522.OK:
                uid = ''.join('{:02X}'.format(x) for x in raw_uid)
                print("UID lido:", uid)
                return uid
        try:
            mqtt_client.check_msg()
        except:
            pass
    return None

def read_cpf_from_keypad():
    print("Digite o CPF; '#' para enviar, '*' apagar")
    cpf = ""
    while True:
        key = keypad.getkey()
        if key:
            print("Tecla:", key)
            if key == '#':
                if cpf:
                    print("CPF completo:", cpf)
                    return cpf
                else:
                    print("CPF vazio - digite algo antes de enviar")
            elif key == '*':
                cpf = cpf[:-1]
            else:
                if key.isdigit() and len(cpf) < 14:
                    cpf += key
            print("Entrada atual:", cpf)
        try:
            mqtt_client.check_msg()
        except:
            pass

def menu_select():
    print("Menu: 1=RFID, 2=Digitar CPF")
    while True:
        key = keypad.getkey()
        if key == '1':
            print("Selecionado: RFID")
            return 'rfid'
        elif key == '2':
            print("Selecionado: CPF")
            return 'cpf'
        try:
            mqtt_client.check_msg()
        except:
            pass


def main_loop():
    while True:
        try:
            try:
                mqtt_client.check_msg()
            except:
                pass

            choice = menu_select()
            if choice == 'rfid':
                uid = read_rfid_once()
                if uid:
                    payload = {"device_id": DEVICE_ID, "method": "rfid", "value": uid, "timestamp": time.time()}
                    ok = mqtt_publish(payload)
                    if ok:
                        print("UID enviado com sucesso")
                        blink_led(led_green, 2, 0.08)
                    else:
                        print("Erro ao enviar UID")
                        blink_led(led_red, 2, 0.2)
                else:
                    print("Timeout leitura RFID")
                    blink_led(led_red, 2)
            elif choice == 'cpf':
                cpf = read_cpf_from_keypad()
                if cpf:
                    payload = {"device_id": DEVICE_ID, "method": "cpf", "value": cpf, "timestamp": time.time()}
                    ok = mqtt_publish(payload)
                    if ok:
                        print("CPF enviado com sucesso")
                        blink_led(led_green, 2)
                    else:
                        print("Erro ao enviar CPF")
                        blink_led(led_red, 2)
            time.sleep(0.2)
        except Exception as e:
            print("Erro main_loop:", e)
            time.sleep(2)

def startup():
    print("Iniciando sistema (sem display)...")
    connect_wifi()
    try:
        mqtt_connect()
    except Exception as e:
        print("MQTT falhou:", e)
        blink_led(led_red, 3)
        time.sleep(2)
    print("Pronto! Use o keypad para selecionar.")
    blink_led(led_green, 2)

startup()
main_loop()
